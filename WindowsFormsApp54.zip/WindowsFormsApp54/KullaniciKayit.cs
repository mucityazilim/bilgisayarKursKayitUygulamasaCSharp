﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp54
{
    public partial class KullaniciKayit : Form
    {
        SqlConnection con = new SqlConnection(" server = .  ; initial catalog = BilKursKayitDB  ; integrated security = sspi  ");
        SqlCommand cmd;

        public KullaniciKayit()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.Show();
        }

        private void button1_Click(object sender, EventArgs e) // YENİ KAYIT 
        {
            try
            {
                if (textBox4.Text == "" || textBox5.Text == "")
                {
                    MessageBox.Show("Tüm alanları doldurunuz ", "eksik işlem ekranı");
                }
                else if (textBox5.Text != textBox6.Text)
                {
                    MessageBox.Show("Parola tekrarı eşleşmiyor !", "Parola kayıt hata ekranı ");
                }
                else
                {
                    con.Open();
                    cmd = new SqlCommand(" insert into login (ad, soyad, telefon, kullaniciAdi, parola, parolaTekrar ) values ( '" + textBox1.Text + "', '" + textBox2.Text + "', '" + textBox3.Text + "', '" + textBox4.Text + "', '" + textBox5.Text + "', '" + textBox6.Text + "'    )    ", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Kullanıcı Kaydı Başarılı ", "Kayıt Ekranı");
                    this.Hide();
                    Form1 f1 = new Form1();
                    f1.Show(); 

                }

            }
            catch (Exception)
            {
                MessageBox.Show("Hatalı İşlem Yaptınız ", "Hata ekranı ");
            }

            finally
            {
                con.Close(); 
            }
        }
    }
}
