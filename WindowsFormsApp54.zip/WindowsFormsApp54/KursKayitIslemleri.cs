﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp54
{
    public partial class KursKayitIslemleri : Form
    {
        SqlConnection con = new SqlConnection(" server = .  ; initial catalog = BilKursKayitDB  ; integrated security = sspi  ");
        SqlCommand cmd;


        public void temizle()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            pictureBox1.ImageLocation = "";
        }
        public void listele()
        {
            SqlDataAdapter da = new SqlDataAdapter(" select * from ogrenciler  ", con);
            DataTable tablo = new DataTable();
            da.Fill(tablo);
            dataGridView1.DataSource = tablo;
            temizle(); 
        }

        public KursKayitIslemleri()
        {
            InitializeComponent();
        }

        private void KursKayitIslemleri_Load(object sender, EventArgs e)
        {
            label2.Text = "Hoşgeldiniz " + Form1.isim;
            listele();
        }

        private void button5_Click(object sender, EventArgs e) // TEMİZLE 
        {
            temizle();
        }

        private void button1_Click(object sender, EventArgs e)     // RESİM EKLEME 
        {
            OpenFileDialog dosya = new OpenFileDialog();
            dosya.Filter = "Resim Dosyaları |*.jpg;*.jpg;*.png |  Tüm Dosyalar |*.*";
            dosya.ShowDialog();
            pictureBox1.ImageLocation = dosya.FileName;
            textBox6.Text = dosya.FileName;

        }

        private void button2_Click(object sender, EventArgs e) // EKLE 
        {
            try
            {

                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
                {
                    MessageBox.Show("Tüm alanları eksiksiz giriniz ", "Eksik kayıt uyarısı");
                }
                else
                {
                    cmd = new SqlCommand("insert into ogrenciler ( ad, soyad, telefon, adres, eposta, resim ) values ( '" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "'  ) ", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Öğrenci Kaydı Başarılı ", "Kayıt Ekranı ");
                }
                // CTRL + K + D   = HİZALAMA 

                

            }
            catch (Exception)
            {
                MessageBox.Show("Hatalı işlem yaptınız !", "Hata ekranı ");
            }

            finally
            {
                con.Close();
                listele(); 

            }



        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            textBox5.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            textBox6.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            pictureBox1.ImageLocation  = dataGridView1.CurrentRow.Cells[6].Value.ToString();


        }

        private void button3_Click(object sender, EventArgs e)  // GÜNCELLE 
        {
            try
            {

                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
                {
                    MessageBox.Show("Tüm alanları eksiksiz giriniz ", "Eksik kayıt uyarısı");
                }
                else
                {
                    cmd = new SqlCommand(" UPDATE  ogrenciler set  ad = '" + textBox1.Text + "', soyad= '" + textBox2.Text + "', telefon = '" + textBox3.Text + "', adres = '" + textBox4.Text + "', eposta= '" + textBox5.Text + "', resim = '" + textBox6.Text + "' where numara = '"+ int.Parse(  dataGridView1.CurrentRow.Cells[0].Value.ToString() ) +"' ", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Güncelleme Başarılı ", "Güncelleme Ekranı ");
                }
                // CTRL + K + D   = HİZALAMA 



            }
            catch (Exception)
            {
                MessageBox.Show("Hatalı işlem yaptınız !", "Hata ekranı ");
            }

            finally
            {
                con.Close();
                listele();

            }



        }

        private void button4_Click(object sender, EventArgs e) // SİL 
        {
            try
            {

                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
                {
                    MessageBox.Show("Silmek istediğiniz kişiyi seçiniz ", "Eksik kayıt uyarısı");
                }
                else
                {
                    cmd = new SqlCommand(" DELETE from  ogrenciler  where numara = '" + int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString()) + "' ", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Silme Başarılı ", "Silme Ekranı ");
                }
                // CTRL + K + D   = HİZALAMA 



            }
            catch (Exception)
            {
                MessageBox.Show("Hatalı işlem yaptınız !", "Hata ekranı ");
            }

            finally
            {
                con.Close();
                listele();

            }




        }

        private void textBox7_TextChanged(object sender, EventArgs e)  // ARAMA KISMA
        {

            SqlDataAdapter da = new SqlDataAdapter(" select * from ogrenciler where Ad like  '"+textBox7.Text+"%'  ", con);
            DataTable tablo = new DataTable();
            da.Fill(tablo);
            dataGridView1.DataSource = tablo;
            temizle();

        }
    }
}
